
import numpy as np

def threshold_averaging(n_sample,ROCS,*karg):
    '''
    Function to compute the average ROC points based on threshold values
    Input: n_sample(number of thresholds considered)
           ROCS(a list of ROC curves, **** BUT ***** there must be a threshold column attached in every ROC curve)
    Output: ROC points of a threshold averaging curve
    '''
    
    # creat an empty array to store result
    # result consists of a set of points on ROC curve
    result=[]
    
    
    # create an empty numpy array to store all clustering score
    score=np.empty(1)
    for points in ROCS:
        score=np.r_[score,points.score]
    # sort the score in descending order    
    score=score[np.argsort(-score)]
    
    
    for tidx in np.arange(0,len(score),int(len(score)/n_sample)):
        fprsum=0
        tprsum=0
        for ROC in ROCS:
            p=ROC_POINT_AT_THRESHOLD(ROC,score[tidx])
            fprsum+=p.fp
            tprsum+=p.tp
        result.append((fprsum/len(ROCS),tprsum/len(ROCS)))
    
    return pd.DataFrame(result,columns=['fp','tp'])