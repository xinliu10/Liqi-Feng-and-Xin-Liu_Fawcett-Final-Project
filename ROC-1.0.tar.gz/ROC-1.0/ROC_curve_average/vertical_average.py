
def verticle_averaging(sample,ROCS,*karg):
    '''
    Function to compute the verticle averaging ROC points for input points of ROC curves
    Input:sample(number of false positive samples, the number of points along the x axis of the averaged ROC curve),
          ROCS(a list of multiple ROC curves, each curve is  stored in DataFrame and has 2 components:fp and tp)
    Output: the averaged ROC points
    '''

    # create an empty array to record result
    result=[]
    # number of roc cruves
    nrocs=len(ROCS)
    
    for fpr_sample in np.arange(0,(1+1/sample),1/sample):
        tprsum=0
        for i in range(nrocs):
            tprsum+=TPR_FOR_FPR(fpr_sample,ROCS[i],ROCS[i].shape[0])
        result.append((fpr_sample,tprsum/nrocs))
    #result.append((1,1))
    return pd.DataFrame(result,columns=['fp','tp'])