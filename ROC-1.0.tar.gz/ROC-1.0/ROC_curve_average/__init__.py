
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def INTERPOLATE(ROCP1,ROCP2,X):
    '''
    Function to compute the slope for interpolation
    Input: two ROC curve points(ROCP1,ROCP2)
           X: target false postivie rate (FPR) 
    Return: The interpolated true positive rate for the given FPR
    '''
    
    slope=(ROCP2.tp-ROCP1.tp)/(ROCP2.fp-ROCP1.fp)
    return ROCP1.tp+slope*(X-ROCP1.fp)

def TPR_FOR_FPR(fpr_sample,ROC,npts):
    '''
    Function to find the largest true positive rate (TPR) for a given false positive rate (FPR)
    Input: fpr_sample (false positive rate fixed)
           ROC (a set of ROC points)
           npts(number of points in ROC)
    Output: The largest TPR or the interpolated TPR for the given FPR in a ROC curve
    '''
    i=1
    while(i<npts and ROC.fp[i] <= fpr_sample):
        i+=1
    
    if ROC.fp[i-1]==fpr_sample:
        return ROC.tp[i-1]
    else:
        return INTERPOLATE(ROC.ix[i-1],ROC.ix[i],fpr_sample)
    
def ROC_POINT_AT_THRESHOLD(ROC,thresh):
    '''
    Function to compute ROC point for a given threshold
    Input: ROC(ROC curve)
           thresh (threshold value)
    Output: ROC point at the given threshold
    '''
    
    for i in range(ROC.shape[0]):
        if ROC.score[i]<thresh:
            break    
    return ROC.ix[i]