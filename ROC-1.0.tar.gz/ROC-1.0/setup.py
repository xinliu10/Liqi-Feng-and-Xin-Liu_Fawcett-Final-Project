from distutils.core import setup

setup(name = "ROC",
      version = "1.0",
      author='Liqi Feng and Xin Liu',
      author_email='erinfeng1013@hotmail.com,xin.liu1@duke.edu',
      url='https://github.com/xinliu10/Sta663-Final-Project',
      py_modules = ['ROC','AUC','roc_graph'],
      packages = ['ROC_curve_average']
      )