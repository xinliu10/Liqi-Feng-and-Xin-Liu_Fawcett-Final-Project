This package were developed using Python 3.5.0 according to "An introduction to ROC analysis" by Fawcett 2005.
Name: ROC
Version: 1.0
Author: Liqi Feng, Xin Liu
Email: erinfeng1013@hotmail.com, xin.liu1@duke.edu
url: https://github.com/xinliu10/Sta663-Final-Project
        
This package contains 3 modules: 
1) ROC, 2) AUC, 3) roc_graph
and 1 subpackage:
1) ROC_curve_average
The subpackage contains 2 modules: 
1) vertical average, 2) threshold average

After downloading this package, it can be installed using !pip install ROC bash command. 