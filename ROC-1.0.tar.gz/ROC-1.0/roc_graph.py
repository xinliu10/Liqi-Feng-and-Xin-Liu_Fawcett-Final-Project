
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def roc_graph(input_rates,title=''):
    '''
    Function to plot the ROC curve and the shaded the area under the curve
    input rates: the ROC points of a classification result
    return: None, plot is generated
    '''
    
    points=input_rates
    
    fig, ax = plt.subplots()
    # plot the roc curve
    plt.plot(points.fp,points.tp,'o-')
    
    # set axis labels and title
    plt.xlabel('False positive rate',fontsize=15)
    plt.ylabel('True positive rate',fontsize=15)
    plt.title(title,fontsize=20)
    
    # shape the area under curve
    verts =  [(points.fp[0], 0)]+list(zip(points.fp,points.tp))+[(points.fp[len(points.fp)-1], 0)]
    poly = plt.Polygon(verts, facecolor='0.8', edgecolor='0.5')
    ax.add_patch(poly)
    
    # plot the 45 degree line in red
    x = np.linspace(*ax.get_xlim())
    ax.plot(x, x,'r')