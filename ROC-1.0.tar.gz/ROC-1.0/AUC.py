
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
    
def AUC(in_data):
    '''
    Function to calculate the area under an ROC curve 
    Input: a DataFrame with actual class label and scores
    Output: A, the area under the ROC curve. 0<A<1.0 
    '''
    
    ## sort the input data in descending order
    dat=in_data.sort_values(by=['score'],ascending=False)
    dat.index=range(dat.shape[0])
    ## compute # of positive labels and negative labels
    P=dat.label[dat.label==1].count()
    N=dat.label[dat.label==0].count()
    
    ## initialize tp and fp to 0
    tp=0
    fp=0
    
    ## initialize previous tp and fp to -inf
    tp_prev=0
    fp_prev=0
    
    ## initialize the AUC score to 0
    A = 0
    
    ## initialize previous score to -inf
    f_prev=-np.inf
    
    ## compute ROC points increasing by fp rate
    for i in range(dat.shape[0]):
        if dat.score[i]!=f_prev:
            A += TRAPEZOID_AREA(fp,fp_prev,tp,tp_prev)
            f_prev = dat.score[i]
            fp_prev = fp
            tp_prev = tp
               
        if dat.label[i]==1:
            tp+=1
        else:
            fp+=1
    
    A = A+TRAPEZOID_AREA(N,fp_prev,N,tp_prev)
    A = A/(P*N) # scale from P · N onto the unit square
    
    return A